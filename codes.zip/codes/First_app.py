'''class Cooler:
    def __init__(self, liters, temperature):
        self.liters = liters
        self.temperature = temperature
    def pour(self, liters):
        if self.liters >= liters:
            self.liters -= liters
            return liters
        else:
            print("недостаточно воды")
            return 0
    def __add__(obj):
        if type(obj) == Cooler:
            return (self.liters + obj.liters, (self.temperature + obj.temperature)//2)
cooler1 = Cooler(liters=100, temperature=10)
print(cooler1.liters)
print(cooler1.pour(50))
print(cooler1.liters)'''
from kivy.app import App
from kivy.uix.button import Button
from kivy.core.window import Window
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
Window.size = (1280, 1920)
col = 0
class TouchScreen(Widget):
    def __init__(self):
        super(TouchScreen, self).__init__()
    def on_touch_down(self, touch):
        print(touch)
    def on_touch_up(self, touch):
        print(touch)
    def on_touch_move(self, touch):
        print(touch)


class MyApp(App):
    def build(self):
        self.knopk1 = Button(text="КПС", size_hint = (0.5,1), pos = (0,0))
        self.knopk1.bind(on_press=self.tup)
        self.knopk2 = Button(text="Давн", size_hint = (0.1,0.1), pos = (360,0))
        self.knopk2.bind(on_press=self.tup2)
        self.lab = Label (text = "Blackstar")
        self.password = TextInput(text = "введи что-то")
        self.box = BoxLayout()
        self.box.add_widget(self.knopk1)
        self.box.add_widget(self.knopk2)
        self.box.add_widget(self.lab)
        self.box.add_widget(self.password)
        return self.box
    def tup(self, instance):
        global col
        col+=1
        self.knopk1.text = str(col)
    def tup2(self, instance):
        self.knopk2.pos = (self.knopk2.pos[0],  self.knopk2.pos[1] + 5)

if __name__ == "__main__":
    MyApp().run()